const {checkout} = require("./script.js")
checkout()